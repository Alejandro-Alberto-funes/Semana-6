package com.example.parcial1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class EnviarTodo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.enviartodo);
        final EditText eNombre= findViewById(R.id.etNombre);
        final EditText eEdad = this.findViewById(R.id.etEdad);
        Button bEnviar2 = this.findViewById(R.id.btEnviar2);

        bEnviar2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nombre = eNombre.getText().toString();
                String edad = eEdad.getText().toString();
                Bundle pasarDatos = new Bundle();
                pasarDatos.putString("eNombre",nombre);
                pasarDatos.putString("eEdad",edad);

                Intent siga= new
                        Intent( EnviarTodo.this,RecibirDatos.class);
                siga.putExtras(pasarDatos);
                startActivity(siga);
            }
        });
    }
}